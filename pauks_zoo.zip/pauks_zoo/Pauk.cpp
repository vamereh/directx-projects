#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)

#include "MRCD9.H"

//-----------------------------------------------------------------------------------
//�������� ����������
LPDIRECT3D9                 D3D          = NULL;	//������� ������ ���������� �����������   
LPDIRECT3DDEVICE9           D3DDevice    = NULL;	//���������� �����������

HINSTANCE hinstance_main;

const int max_pauk=10;   //���������� �������� ����� (������)
const int max_eda=10;    //���������� ������ ��� 

ofstream outf("log.txt"); //���� ������

//�������� �������
CUNIT* Pauk = new CUNIT[max_pauk];
CUNIT* Eda = new CUNIT[max_eda];
CENVIRONMENT Ground(1.0f, RR_LIGHTOFF, NULL);
CENVIRONMENT Sky(1.0f, RR_LIGHTOFF, NULL);
CII II[max_pauk];

//������
float camera_place_X=0, camera_place_Y=0, camera_place_Z=0;
float camera_ang=0;
float camera_dist=2500;
D3DXMATRIX matView;

//���������� �����
DWORD LastTime=timeGetTime();
DWORD ElapsedTime=0;

int time_to_tired = 0;

//-----------------------------------------------------------------------------------
//���������� �������

LRESULT CALLBACK MainWinProc(HWND   hwnd,            
					        UINT    msg,              
                            WPARAM  wparam,           
                            LPARAM  lparam);

int WINAPI WinMain(	HINSTANCE hinstance,
					HINSTANCE hprevinstance,
					LPSTR lpcmdline,
					int ncmdshow);

HRESULT InitialObjects();

VOID InitLightMaterial();

VOID Rendering(); 

VOID DeleteDirect3D();       

//-----------------------------------------------------------------------------------

LRESULT CALLBACK MainWinProc(HWND   hwnd,            
					        UINT    msg,              
                            WPARAM  wparam,           
                            LPARAM  lparam)          
{

switch(msg)
	{	
	
     case WM_DESTROY: 
		 {
		 DeleteDirect3D();
		 PostQuitMessage(0);
		 return(0);
		 } 
	 case WM_KEYDOWN:
		 {
			 if (wparam == VK_ESCAPE) {PostQuitMessage(0);return 0;};
			 if (wparam == VK_RIGHT) {if (camera_ang>=0) {camera_ang-=10;} else {camera_ang=350;};};
			 if (wparam == VK_LEFT) {if (camera_ang<=350) {camera_ang+=10;} else {camera_ang=0;};};
			 if (wparam == VK_UP) 
			 {
				 camera_place_X=(float)(-15*cos(D3DXToRadian(camera_ang))+camera_place_X);
				 camera_place_Y=(float)(-15*sin(D3DXToRadian(camera_ang))+camera_place_Y);
				
			 };
			 if (wparam == VK_DOWN) 
			 {
				 camera_place_X=(float)(15*cos(D3DXToRadian(camera_ang))+camera_place_X);
				 camera_place_Y=(float)(15*sin(D3DXToRadian(camera_ang))+camera_place_Y);
				
			 };
			 if (wparam == VK_PRIOR) {if (camera_dist<=3000) {camera_dist+=10;};};
			 if (wparam == VK_NEXT) {if (camera_dist>=300) {camera_dist-=10;};};

			 break;
		 }
	} 

  
return DefWindowProc(hwnd, msg, wparam, lparam);

} 

//-----------------------------------------------------------------------------------

int WINAPI WinMain(	HINSTANCE hinstance,
					HINSTANCE hprevinstance,
					LPSTR lpcmdline,
					int ncmdshow)
{
MSG        msg;
HWND       hwnd;
hinstance_main = hinstance;//������ ����� GetSystemMetrics(SM_CXSCREEN)GetSystemMetrics(SM_CYSCREEN)

hwnd = InitMainForm(hinstance, MainWinProc, "D3D Pauk", GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN) );

if( SUCCEEDED( InitD3D(&D3D, &D3DDevice, hwnd, FALSE, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN) ) ) )
  { 
       if( SUCCEEDED( InitialObjects() ) )
	    {
           ShowWindow( hwnd, SW_SHOWDEFAULT );
           UpdateWindow( hwnd );

              ZeroMemory( &msg, sizeof(msg));
              while( msg.message!=WM_QUIT) 
                {
                  if(PeekMessage( &msg, NULL,0,0,PM_REMOVE ))
		           {
			          TranslateMessage( &msg );
                      DispatchMessage( &msg );
                   }
                  else
                  Rendering();
                } 
        }
  }
 
return 0;
}

//-----------------------------------------------------------------------------------
//������������� ��������

HRESULT InitialObjects()
{
    if(D3DDevice == NULL)        
        return E_FAIL;

	HRESULT hRet;

	for (unsigned short int i=0; i<max_pauk; i++)
	{
		hRet=Pauk[i].CreateModelFF("Pauk.bma", D3DDevice, 100.0f*i);
		Pauk[i].Place.x = (float)floor(2000*rand()/RAND_MAX)-1000;
		Pauk[i].Place.y = (float)floor(2000*rand()/RAND_MAX)-1000;
		Pauk[i].Place.z=500.0f;
		//Pauk[i].rrlight = RR_LIGHTON;
		II[i].order = U_EAT;
	};
	if(FAILED(hRet)) {return hRet;};

	for (i=0; i<max_eda; i++)
	{
		hRet=Eda[i].CreateModelFF("eda.bma", D3DDevice, 600.0f*i);
		Eda[i].Place.x=(float)floor(2000*rand()/RAND_MAX)-1000;
		Eda[i].Place.y=(float)floor(2000*rand()/RAND_MAX)-1000;
		Eda[i].Place.z=1000.0f;
	};
	if(FAILED(hRet)) {return hRet;};

	//InitLightMaterial();
	
	Ground.CreateModelFF("Ground.bma", D3DDevice);
	//Ground.rrlight = RR_LIGHTON;
	Sky.CreateModelFF("Sky.bma", D3DDevice);

	return hRet;
}

//-----------------------------------------------------------------------------------

VOID InitLightMaterial()
{
    D3DMATERIAL9  Material; 
    D3DLIGHT9     Light0;    

	ZeroMemory( &Material, sizeof(D3DMATERIAL9) );
    Material.Diffuse.r = Material.Ambient.r = 1.0f;
    Material.Diffuse.g = Material.Ambient.g = 1.0f;
    Material.Diffuse.b = Material.Ambient.b = 1.0f;
    Material.Diffuse.a = Material.Ambient.a = 1.0f;
	
    D3DDevice->SetMaterial( &Material );
   
	//������ ��������
    ZeroMemory( &Light0, sizeof(D3DLIGHT9) );
    Light0.Type       = D3DLIGHT_POINT;
    Light0.Diffuse.r  = 6.0f;
    Light0.Diffuse.g  = 6.0f;
    Light0.Diffuse.b  = 6.0f;
    Light0.Range      = 5000.0f;
	Light0.Position   = D3DXVECTOR3(0,0,1000.0f);
    //D3DXVec3Normalize( (D3DXVECTOR3*)&Light.Direction, &VectorDir );
    D3DDevice->SetLight( 0, &Light0 );
	D3DDevice->LightEnable( 0, TRUE );

    D3DDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
    D3DDevice->SetRenderState( D3DRS_AMBIENT, 0 );
}

//-----------------------------------------------------------------------------------

VOID Rendering()
{
	if(D3DDevice == NULL)        
        return;


	ElapsedTime=timeGetTime()-LastTime;
	if (ElapsedTime>=25)
	{

		//���������� �����
		LastTime=timeGetTime();

		//--------------------------------������----------------------
	    //������� ���� (������)
		D3DXVECTOR3 Cam_Pos = D3DXVECTOR3(camera_dist*cos(D3DXToRadian(camera_ang))+camera_place_X, 
										  camera_dist*sin(D3DXToRadian(camera_ang))+camera_place_Y, 
										  camera_dist);
		D3DXVECTOR3 Cam_Look_To = D3DXVECTOR3(camera_place_X, camera_place_Y, camera_place_Z);
	    D3DXMatrixLookAtLH(&matView, &Cam_Pos, &Cam_Look_To, &D3DXVECTOR3(0.0f, 0.0f, 1.0f));
	    D3DDevice->SetTransform(D3DTS_VIEW, &matView);
		//�������� ���� �� �������
		Sky.Place.x = camera_place_X;
		Sky.Place.y = camera_place_Y;
		Sky.Place.z = camera_place_Z;


		for (unsigned short int i=0; i<max_eda; i++)
		{
			if (Eda[i].visible == FALSE)
			{
				Eda[i].Place.x = (float)floor(2000*rand()/RAND_MAX)-1000;
				Eda[i].Place.y = (float)floor(2000*rand()/RAND_MAX)-1000;
				Eda[i].Place.z = 1000.0f;
				Eda[i].visible = TRUE;
			};
		};

		if (time_to_tired<350) time_to_tired++;
		else
		{
			time_to_tired = 0;
			for (i=0; i<max_pauk; i++)
			{ 
			 if(Pauk[i].CP>0) Pauk[i].CP--;

		
			 //if (II[i].action == U_ATTACK)
			  //if(Pauk[II[i].target].HP>0) Pauk[II[i].target].HP--;

			
			 //if (II[i].order == U_RELAX)
			  //if(Pauk[i].HP<10) Pauk[i].HP+=5;
			};
			
		};

		//-------------------------------II----------------------------
		for (i=0; i<max_pauk; i++)
		{
			/*if (i==0){
			outf <<"Pauk["<<i<<"]====="<<endl;
			outf <<"HP = "<<Pauk[i].HP<<endl;
			outf <<"CP = "<<Pauk[i].CP<<endl;
			outf <<"kol paukov = "<<II[i].net->in_neron[2].U<<endl;
			outf <<"kol edi = "<<II[i].net->in_neron[3].U<<endl;
			
			if (II[i].order == U_WALK)
				outf <<"II[i].order = ������"<<endl;
			if (II[i].order == U_RUNAWAY)
				outf <<"II[i].order = �������"<<endl;
			if (II[i].order == U_RELAX)
				outf <<"II[i].order = ��������"<<endl;
			if (II[i].order == U_EAT)
				outf <<"II[i].order = ����"<<endl;
			if (II[i].order == U_ATTACK)
				outf <<"II[i].order = ���������"<<endl;
			
			outf <<"================"<<endl;
			}*/	
			//����� ��������
			II[i].GenerateAction(Pauk, Eda, i, max_pauk, max_eda);
			
		
			//����� �������� �� ������ �������
			if (II[i].action == U_MOVE || II[i].action == U_TURN) {if (Pauk[i].a_nom!=0){ Pauk[i].SetAnimation(0);};};
			if (II[i].action == U_STOP) {if (Pauk[i].a_nom!=1){ Pauk[i].SetAnimation(1);};};
			if (II[i].action == U_ATTACK) 
			{
				if (Pauk[i].a_nom!=2)
				{ 
					Pauk[i].SetAnimation(2);
					
				};
			};
			if (II[i].action == U_PLAYEATANIM) 
			{ 
				if (Pauk[i].a_nom!=3) Pauk[i].SetAnimation(3);
				Eda[II[i].target].rotate = Pauk[i].rotate;
				if (Eda[II[i].target].a_nom!=1) {Eda[II[i].target].SetAnimation(1);};
			};
			if (II[i].order == U_RUNAWAY)
			{
				if(Pauk[i].speed != 10)
				{
					Pauk[i].speed = 10;
					Pauk[i].a_add = 0.04f;
					Pauk[i].SetAnimation(Pauk[i].a_nom);
				}
	
			}
	
		};
		
		//--------------------------------�����---------------------------
		for (i=0; i<max_pauk; i++)
		{
			Pauk[i].Play();
			//��������� ����������� �� ������ ���������� ��������
			_UACTION lastact = II[i].action;
			II[i].action = Pauk[i].DoAction(II[i].action , II[i].angle);
			if (lastact!=II[i].action) II[i].tic = II[i].max_tic;
			//������ ����������� � ��������� ��������� � ������������ �� ������� ���� ����� 
			Pauk[i].Gravity(Ground.Mesh.Vertex, Ground.Mesh.kol_vertex);
		};		
		//--------------------------------�����---------------------------
		for (i=0; i<max_eda; i++)
		{
			if (Eda[i].a_position>1-Eda[i].a_add) {Eda[i].SetAnimation(0);};
			Eda[i].Play();
			Eda[i].Gravity(Ground.Mesh.Vertex, Ground.Mesh.kol_vertex);
		};
		//������ ����
		D3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(200,200,200), 1.0f, 0 );
		D3DDevice->BeginScene();
		
		Sky.Present();

		Ground.Present();
		
		for (i=0; i<max_pauk; i++)
		{
			Pauk[i].Present();
		};

		for (i=0; i<max_eda; i++)
		{
			Eda[i].Present();
		};

		D3DDevice->EndScene();       
		D3DDevice->Present( NULL, NULL, 0, NULL );

	}
}

//-----------------------------------------------------------------------------------
//����������� ��������

VOID DeleteDirect3D()
{ 

	outf.close();

	Sky.Release();
	
	Ground.Release();
	
	for (unsigned short int i=0; i<max_eda; i++)
	{
		Eda[i].Release();
	};
	
	for (i=0; i<max_pauk; i++)
	{
		Pauk[i].Release();
	};

	delete [max_eda] Eda;
	delete [max_pauk] Pauk;

	if( D3DDevice != NULL) 
        D3DDevice->Release();

    if( D3D != NULL)
        D3D->Release();
}

//-----------------------------------------------------------------------------------